﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Entity
{
    public class MovieDetails
    {
        public string Name { set; get; }
        public string IMDB { set; get; }
        public string Language { set; get; }
        public string Category { set; get; }
        public string Path { set; get; }

    }
}
