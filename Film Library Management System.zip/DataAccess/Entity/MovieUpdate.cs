﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Entity
{
    public class MovieUpdate
    {
        public string Name { set; get; }
        public string IMDB { set; get; }
    }
}
