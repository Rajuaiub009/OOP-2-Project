﻿
namespace Film_Library_Management_System
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignUp));
            this.lblFirstname = new System.Windows.Forms.Label();
            this.lblLastname = new System.Windows.Forms.Label();
            this.lblEmailaddress = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblRetypepassword = new System.Windows.Forms.Label();
            this.txtfname = new System.Windows.Forms.TextBox();
            this.txtlname = new System.Windows.Forms.TextBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.txtRetypepassword = new System.Windows.Forms.TextBox();
            this.btnSignup = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblBack = new System.Windows.Forms.Label();
            this.txtUser = new System.Windows.Forms.TextBox();
            this.txtUsername = new System.Windows.Forms.Label();
            this.txtuname = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblFirstname
            // 
            this.lblFirstname.AutoSize = true;
            this.lblFirstname.BackColor = System.Drawing.Color.DimGray;
            this.lblFirstname.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstname.ForeColor = System.Drawing.Color.Transparent;
            this.lblFirstname.Location = new System.Drawing.Point(107, 109);
            this.lblFirstname.Name = "lblFirstname";
            this.lblFirstname.Size = new System.Drawing.Size(102, 20);
            this.lblFirstname.TabIndex = 0;
            this.lblFirstname.Text = "First Name :";
            // 
            // lblLastname
            // 
            this.lblLastname.AutoSize = true;
            this.lblLastname.BackColor = System.Drawing.Color.DimGray;
            this.lblLastname.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLastname.ForeColor = System.Drawing.Color.Transparent;
            this.lblLastname.Location = new System.Drawing.Point(107, 170);
            this.lblLastname.Name = "lblLastname";
            this.lblLastname.Size = new System.Drawing.Size(100, 20);
            this.lblLastname.TabIndex = 1;
            this.lblLastname.Text = "Last Name :";
            // 
            // lblEmailaddress
            // 
            this.lblEmailaddress.AutoSize = true;
            this.lblEmailaddress.BackColor = System.Drawing.Color.DimGray;
            this.lblEmailaddress.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmailaddress.ForeColor = System.Drawing.Color.White;
            this.lblEmailaddress.Location = new System.Drawing.Point(146, 268);
            this.lblEmailaddress.Name = "lblEmailaddress";
            this.lblEmailaddress.Size = new System.Drawing.Size(61, 20);
            this.lblEmailaddress.TabIndex = 2;
            this.lblEmailaddress.Text = "Email :";
            // 
            // lblPassword
            // 
            this.lblPassword.AutoSize = true;
            this.lblPassword.BackColor = System.Drawing.Color.DimGray;
            this.lblPassword.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.ForeColor = System.Drawing.Color.Transparent;
            this.lblPassword.Location = new System.Drawing.Point(114, 322);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(93, 20);
            this.lblPassword.TabIndex = 3;
            this.lblPassword.Text = "Password :";
            // 
            // lblRetypepassword
            // 
            this.lblRetypepassword.AutoSize = true;
            this.lblRetypepassword.BackColor = System.Drawing.Color.DimGray;
            this.lblRetypepassword.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRetypepassword.ForeColor = System.Drawing.Color.Transparent;
            this.lblRetypepassword.Location = new System.Drawing.Point(47, 383);
            this.lblRetypepassword.Name = "lblRetypepassword";
            this.lblRetypepassword.Size = new System.Drawing.Size(162, 20);
            this.lblRetypepassword.TabIndex = 4;
            this.lblRetypepassword.Text = "Re-Type Password :";
            // 
            // txtfname
            // 
            this.txtfname.BackColor = System.Drawing.Color.DimGray;
            this.txtfname.ForeColor = System.Drawing.Color.White;
            this.txtfname.Location = new System.Drawing.Point(236, 109);
            this.txtfname.Name = "txtfname";
            this.txtfname.Size = new System.Drawing.Size(196, 22);
            this.txtfname.TabIndex = 5;
            // 
            // txtlname
            // 
            this.txtlname.BackColor = System.Drawing.Color.DimGray;
            this.txtlname.ForeColor = System.Drawing.Color.White;
            this.txtlname.Location = new System.Drawing.Point(236, 168);
            this.txtlname.Name = "txtlname";
            this.txtlname.Size = new System.Drawing.Size(196, 22);
            this.txtlname.TabIndex = 6;
            // 
            // txtemail
            // 
            this.txtemail.BackColor = System.Drawing.Color.DimGray;
            this.txtemail.ForeColor = System.Drawing.Color.White;
            this.txtemail.Location = new System.Drawing.Point(236, 266);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(196, 22);
            this.txtemail.TabIndex = 7;
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.Color.DimGray;
            this.txtPassword.ForeColor = System.Drawing.Color.White;
            this.txtPassword.Location = new System.Drawing.Point(236, 320);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(196, 22);
            this.txtPassword.TabIndex = 8;
            // 
            // txtRetypepassword
            // 
            this.txtRetypepassword.BackColor = System.Drawing.Color.DimGray;
            this.txtRetypepassword.ForeColor = System.Drawing.Color.White;
            this.txtRetypepassword.Location = new System.Drawing.Point(236, 381);
            this.txtRetypepassword.Name = "txtRetypepassword";
            this.txtRetypepassword.Size = new System.Drawing.Size(196, 22);
            this.txtRetypepassword.TabIndex = 9;
            // 
            // btnSignup
            // 
            this.btnSignup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.btnSignup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignup.ForeColor = System.Drawing.Color.Transparent;
            this.btnSignup.Location = new System.Drawing.Point(260, 439);
            this.btnSignup.Name = "btnSignup";
            this.btnSignup.Size = new System.Drawing.Size(97, 33);
            this.btnSignup.TabIndex = 10;
            this.btnSignup.Text = "Sign Up";
            this.btnSignup.UseVisualStyleBackColor = false;
            this.btnSignup.Click += new System.EventHandler(this.btnSignup_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DimGray;
            this.label1.Font = new System.Drawing.Font("Yu Gothic", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(177, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(262, 32);
            this.label1.TabIndex = 11;
            this.label1.Text = "Film Library Sign Up";
            // 
            // lblBack
            // 
            this.lblBack.AutoSize = true;
            this.lblBack.BackColor = System.Drawing.Color.DimGray;
            this.lblBack.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBack.ForeColor = System.Drawing.Color.White;
            this.lblBack.Location = new System.Drawing.Point(515, 517);
            this.lblBack.Name = "lblBack";
            this.lblBack.Size = new System.Drawing.Size(47, 20);
            this.lblBack.TabIndex = 12;
            this.lblBack.Text = "Back";
            this.lblBack.Click += new System.EventHandler(this.lblBack_Click);
            // 
            // txtUser
            // 
            this.txtUser.Location = new System.Drawing.Point(274, 515);
            this.txtUser.Name = "txtUser";
            this.txtUser.Size = new System.Drawing.Size(53, 22);
            this.txtUser.TabIndex = 13;
            this.txtUser.Text = "User";
            // 
            // txtUsername
            // 
            this.txtUsername.AutoSize = true;
            this.txtUsername.BackColor = System.Drawing.Color.DimGray;
            this.txtUsername.Font = new System.Drawing.Font("Arial Unicode MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtUsername.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.txtUsername.Location = new System.Drawing.Point(111, 220);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(96, 20);
            this.txtUsername.TabIndex = 14;
            this.txtUsername.Text = "Username :";
            // 
            // txtuname
            // 
            this.txtuname.BackColor = System.Drawing.Color.DimGray;
            this.txtuname.ForeColor = System.Drawing.Color.White;
            this.txtuname.Location = new System.Drawing.Point(236, 218);
            this.txtuname.Name = "txtuname";
            this.txtuname.Size = new System.Drawing.Size(196, 22);
            this.txtuname.TabIndex = 15;
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(574, 549);
            this.Controls.Add(this.txtuname);
            this.Controls.Add(this.txtUsername);
            this.Controls.Add(this.txtUser);
            this.Controls.Add(this.lblBack);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnSignup);
            this.Controls.Add(this.txtRetypepassword);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.txtlname);
            this.Controls.Add(this.txtfname);
            this.Controls.Add(this.lblRetypepassword);
            this.Controls.Add(this.lblPassword);
            this.Controls.Add(this.lblEmailaddress);
            this.Controls.Add(this.lblLastname);
            this.Controls.Add(this.lblFirstname);
            this.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.MaximizeBox = false;
            this.Name = "SignUp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SignUp";
            this.Load += new System.EventHandler(this.SignUp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFirstname;
        private System.Windows.Forms.Label lblLastname;
        private System.Windows.Forms.Label lblEmailaddress;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblRetypepassword;
        private System.Windows.Forms.TextBox txtfname;
        private System.Windows.Forms.TextBox txtlname;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.TextBox txtRetypepassword;
        private System.Windows.Forms.Button btnSignup;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblBack;
        private System.Windows.Forms.TextBox txtUser;
        private System.Windows.Forms.Label txtUsername;
        private System.Windows.Forms.TextBox txtuname;
    }
}